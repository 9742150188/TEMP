package ControlStatements;

public class program1 {
	
	public static void main(String[] args) {
		int x = 10;
	    int y = 12;
	    
	    if((x+y)>20) {
	    	System.out.println("X+Y is greater than 20");
	    }
	}

}
