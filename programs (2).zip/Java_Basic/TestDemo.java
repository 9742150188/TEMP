package Java_Basic;

 class Demo{
	int x;
}

public class TestDemo {
	
	public static void main(String[] args) {
		Demo myObj = new Demo();
		myObj.x = 10;
		System.out.println(myObj.x);
	}

}
