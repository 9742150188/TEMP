package Java_Basic;

public class TypeCasting {
	
	public static void main(String[] args) {
		float num = 8990.00f;
		int inNum = (int)num;
		
		int secNum = 8999;
		float FloatSecNum = secNum;
		
		char c = 97;
		
		System.out.println(c);
		System.out.println(FloatSecNum);
		System.out.println(inNum);
	}

}
