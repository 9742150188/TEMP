package OOP;

class Demo_class{
	int x;
}

public class Demo {
	public static void main(String[] args) {
		Demo_class obj = new Demo_class();
		obj.x = 100;
		System.out.println(obj.x);
	}
}
